from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text, Date
from sqlalchemy.types import TIMESTAMP
from sqlalchemy.sql import func
from database import Base

class User(Base):
    __tablename__ = "users"

    user_id = Column(Integer, primary_key=True, index=True)
    full_name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now())

class RecommendationField(Base):
    __tablename__ = "recommendation_fields"

    field_id = Column(Integer, primary_key=True, index=True)
    field_name = Column(String, nullable=False)
    length = Column(Float, nullable=False)
    width = Column(Float, nullable=False)
    location = Column(String, nullable=False)
    user_id = Column(Integer, ForeignKey("users.user_id"))
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now())

class FieldData(Base):
    __tablename__ = "field_data"

    id = Column(Integer, primary_key=True, index=True)
    field_name = Column(String, nullable=False)
    location = Column(String, nullable=False)
    width = Column(Float, nullable=False)
    length = Column(Float, nullable=False)
    temperature = Column(Float, nullable=False)
    rainfall = Column(Float, nullable=False)
    nitrogen = Column(Integer, nullable=False)
    phosphorus = Column(Integer, nullable=False)
    potassium = Column(Integer, nullable=False)
    soil_ph = Column(Float, nullable=False)
    humidity = Column(Float, nullable=False)
    user_id = Column(Integer, ForeignKey("users.user_id"))
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now())

class TrackCrop(Base):
    __tablename__ = "track_crop"

    id = Column(Integer, primary_key=True, index=True)
    field_id = Column(Integer, ForeignKey("field_data.id", ondelete="CASCADE"))
    crop_planted = Column(String, nullable=False)
    date_planted = Column(Date, nullable=False)
    notes = Column(Text)
    user_id = Column(Integer, ForeignKey("users.user_id"))
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now())
