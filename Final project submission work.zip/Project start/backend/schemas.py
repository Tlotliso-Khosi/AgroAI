from pydantic import BaseModel
from datetime import datetime, date
from typing import Optional

class CropBase(BaseModel):
    fieldname: str
    width: float
    height: float
    length: float
    location: str

class CropCreate(CropBase):
    pass

class Crop(CropBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True

class UserCreate(BaseModel):
    full_name: str
    email: str
    password: str

class UserLogin(BaseModel):
    username: str  # matched to 'email'
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str
    user_id: int
    email: str
    full_name: str

class FieldBase(BaseModel):
    field_name: str
    length: float
    width: float
    location: str

class FieldDataCreate(BaseModel):
    field_name: str
    location: str
    width: float
    length: float
    temperature: float
    rainfall: float
    nitrogen: int
    phosphorus: int
    potassium: int
    soil_ph: float
    humidity: float

class TrackCropCreate(BaseModel):
    field_name: str
    crop_planted: str
    date_planted: date
    notes: Optional[str] = None

class TrackCropUpdate(BaseModel):
    crop_planted: str
    date_planted: date
    notes: Optional[str] = None
