from fastapi import FastAPI, Depends, HTTPException, status, Form, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from passlib.context import CryptContext
from jose import JWTError, jwt
from sqlalchemy.orm import Session
from typing import List, Optional
import joblib
import pandas as pd
from databases import Database
import uuid
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv
from pydantic import BaseModel

# Import model comparison function
try:
    from model2 import compare_crop_with_expert_advice
except ImportError:
    # Fallback function if model2.py is not available
    def compare_crop_with_expert_advice(crop, readings):
        return ["This is a placeholder for crop comparison analysis."]

# Load environment variables
load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://agroai_user:agroai%40Nul0._@localhost:5432/agroai_db")
database = Database(DATABASE_URL)

# Security configuration
SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Load ML model if available
try:
    model = joblib.load("crop_recommendation_model.pkl")
    model_loaded = True
except:
    print("Warning: Crop recommendation model not found. Recommendation endpoint will not work.")
    model_loaded = False

# Security setup
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# Define FastAPI app
app = FastAPI()

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models
class CropRecommendationRequest(BaseModel):
    N: int
    P: int
    K: int
    temperature: float
    humidity: float
    ph: float
    rainfall: float

class UserCreate(BaseModel):
    email: str
    password: str
    full_name: Optional[str] = None

class UserInDB(BaseModel):
    user_id: str
    email: str
    password_hash: str
    full_name: Optional[str] = None
    created_at: Optional[datetime] = None

class LoginRequest(BaseModel):
    email: str
    password: str
    
class CropComparisonRequest(BaseModel):
    desired_crop: str
    N: int
    P: int
    K: int
    temperature: float
    humidity: float
    ph: float
    rainfall: float

class Token(BaseModel):
    access_token: str
    token_type: str
    user_id: str
    email: str
    full_name: Optional[str] = None

class FieldBase(BaseModel):
    field_name: str
    length: float
    width: float
    location: str

class FieldDataCreate(BaseModel):
    field_name: str
    location: str
    width: float
    length: float
    temperature: float
    rainfall: float
    nitrogen: int
    phosphorus: int
    potassium: int
    soil_ph: float
    humidity: float

class TrackCropCreate(BaseModel):
    field_name: str
    crop_planted: str
    date_planted: datetime
    notes: Optional[str] = None

# Database connection events
@app.on_event("startup")
async def startup():
    try:
        await database.connect()
        # Verify connection
        version = await database.fetch_val("SELECT version()")
        print(f"Connected to PostgreSQL: {version}")
        
        # Create tables if they don't exist
        await create_tables()
    except Exception as e:
        print(f"Database connection failed: {str(e)}")
        raise

@app.on_event("shutdown")
async def shutdown():
    await database.disconnect()

async def create_tables():
    """Create necessary tables if they don't exist"""
    
    # Users table
    await database.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id UUID PRIMARY KEY,
            email VARCHAR(255) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            full_name VARCHAR(255),
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Fields table
    await database.execute("""
        CREATE TABLE IF NOT EXISTS recommendation_fields (
            field_id SERIAL PRIMARY KEY,
            field_name VARCHAR(100) NOT NULL,
            length FLOAT NOT NULL,
            width FLOAT NOT NULL,
            location VARCHAR(255) NOT NULL,
            user_id UUID REFERENCES users(user_id),
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Field data table
    await database.execute("""
        CREATE TABLE IF NOT EXISTS field_data (
            id SERIAL PRIMARY KEY,
            field_name VARCHAR(100) NOT NULL,
            location VARCHAR(255) NOT NULL,
            width FLOAT NOT NULL,
            length FLOAT NOT NULL,
            temperature FLOAT NOT NULL,
            rainfall FLOAT NOT NULL,
            nitrogen INTEGER NOT NULL,
            phosphorus INTEGER NOT NULL,
            potassium INTEGER NOT NULL,
            soil_ph FLOAT NOT NULL,
            humidity FLOAT NOT NULL,
            user_id UUID REFERENCES users(user_id),
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Crop tracking table
    await database.execute("""
        CREATE TABLE IF NOT EXISTS track_crop (
            id SERIAL PRIMARY KEY,
            field_id INTEGER REFERENCES field_data(id) ON DELETE CASCADE,
            crop_planted VARCHAR(100) NOT NULL,
            date_planted DATE NOT NULL,
            notes TEXT,
            user_id UUID REFERENCES users(user_id),
            created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        )
    """)

# Authentication functions
def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

async def get_user(email: str):
    query = "SELECT * FROM users WHERE email = :email"
    return await database.fetch_one(query=query, values={"email": email})

async def get_user_by_id(user_id: str):
    query = "SELECT * FROM users WHERE user_id = :user_id"
    return await database.fetch_one(query=query, values={"user_id": user_id})

async def authenticate_user(email: str, password: str):
    user = await get_user(email)
    if not user or not verify_password(password, user["password_hash"]):
        return False
    return user

def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    
    user = await get_user(email)
    if user is None:
        raise credentials_exception
    return user

# Routes
@app.post("/login", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = await authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user["email"]},
        expires_delta=access_token_expires
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user_id": str(user["user_id"]),
        "email": user["email"],
        "full_name": user["full_name"]
    }

@app.get("/")
async def read_root():
    return {"message": "Welcome to the AgroAI API"}

# User registration endpoint
@app.post("/register", status_code=status.HTTP_201_CREATED)
async def register(user: UserCreate):
    # Check if user exists
    existing_user = await get_user(user.email)
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Hash password
    hashed_password = get_password_hash(user.password)
    
    # Create new user
    user_id = uuid.uuid4()
    query = """
        INSERT INTO users 
        (user_id, email, password_hash, full_name)
        VALUES (:user_id, :email, :password_hash, :full_name)
        RETURNING user_id, email, full_name, created_at
    """
    values = {
        "user_id": user_id,
        "email": user.email,
        "password_hash": hashed_password,
        "full_name": user.full_name
    }
    
    result = await database.fetch_one(query=query, values=values)
    
    # Create access token
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.email},
        expires_delta=access_token_expires
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user_id": str(result["user_id"]),
        "email": result["email"],
        "full_name": result["full_name"]
    }

@app.get("/users/me")
async def read_users_me(current_user: dict = Depends(get_current_user)):
    return {
        "user_id": str(current_user["user_id"]),
        "email": current_user["email"],
        "full_name": current_user["full_name"],
        "created_at": current_user["created_at"]
    }

# Recommendation endpoint
@app.post("/recommend")
async def recommend_crop(
    request: CropRecommendationRequest,
    current_user: dict = Depends(get_current_user)
):
    if not model_loaded:
        raise HTTPException(
            status_code=503,
            detail="Crop recommendation model is not available"
        )
        
    input_data = pd.DataFrame([{
        "N": request.N,
        "P": request.P,
        "K": request.K,
        "temperature": request.temperature,
        "humidity": request.humidity,
        "ph": request.ph,
        "rainfall": request.rainfall,
    }])
    
    try:
        prediction = model.predict(input_data)
        
        # Log this recommendation
        query = """
            INSERT INTO field_data 
            (field_name, location, width, length, temperature, rainfall, 
             nitrogen, phosphorus, potassium, soil_ph, humidity, user_id)
            VALUES 
            ('Recommendation', 'API Request', 0, 0, :temperature, :rainfall,
             :nitrogen, :phosphorus, :potassium, :ph, :humidity, :user_id)
        """
        values = {
            "temperature": request.temperature,
            "rainfall": request.rainfall,
            "nitrogen": request.N,
            "phosphorus": request.P,
            "potassium": request.K,
            "ph": request.ph,
            "humidity": request.humidity,
            "user_id": current_user["user_id"]
        }
        await database.execute(query=query, values=values)
        
        return {"recommended_crop": prediction[0]}
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Prediction failed: {str(e)}"
        )

@app.post("/compare_crop")
async def compare_crop(
    request: CropComparisonRequest,
    current_user: dict = Depends(get_current_user)
):
    try:
        # Map fields to match model2.py expectations
        ui_readings = {
            'temperature': request.temperature,
            'soil_ph': request.ph,
            'rainfall': request.rainfall,
            'humidity': request.humidity,
            'nitrogen': request.N,
            'phosphorus': request.P,
            'potassium': request.K
        }
        
        # Get expert analysis
        analysis = compare_crop_with_expert_advice(
            request.desired_crop,
            ui_readings
        )
        
        # Calculate compatibility score
        score = 100 - (analysis.count("⚠️") * 15)
        score = max(10, min(100, score))
        
        # Log this comparison
        query = """
            INSERT INTO field_data 
            (field_name, location, width, length, temperature, rainfall, 
             nitrogen, phosphorus, potassium, soil_ph, humidity, user_id)
            VALUES 
            (:crop_name, 'Crop Comparison', 0, 0, :temperature, :rainfall,
             :nitrogen, :phosphorus, :potassium, :ph, :humidity, :user_id)
        """
        values = {
            "crop_name": f"Comparison: {request.desired_crop}",
            "temperature": request.temperature,
            "rainfall": request.rainfall,
            "nitrogen": request.N,
            "phosphorus": request.P,
            "potassium": request.K,
            "ph": request.ph,
            "humidity": request.humidity,
            "user_id": current_user["user_id"]
        }
        await database.execute(query=query, values=values)
        
        return {
            "compatibility_score": score,
            "feedback": analysis,
            "recommended_crop": request.desired_crop
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Analysis failed: {str(e)}"
        )

# Field management endpoints
@app.post("/fields")
async def create_field(
    field: FieldBase,
    current_user: dict = Depends(get_current_user)
):
    query = """
        INSERT INTO recommendation_fields 
        (field_name, length, width, location, user_id)
        VALUES (:field_name, :length, :width, :location, :user_id)
        RETURNING field_id
    """
    values = {
        "field_name": field.field_name,
        "length": field.length,
        "width": field.width,
        "location": field.location,
        "user_id": current_user["user_id"]
    }
    
    result = await database.fetch_one(query=query, values=values)
    return {"field_id": result["field_id"], "message": "Field created successfully"}

@app.get("/fields")
async def get_fields(current_user: dict = Depends(get_current_user)):
    query = """
        SELECT field_id, field_name, length, width, location, created_at
        FROM recommendation_fields
        WHERE user_id = :user_id
        ORDER BY created_at DESC
    """
    fields = await database.fetch_all(query=query, values={"user_id": current_user["user_id"]})
    return fields

@app.delete("/fields/{field_id}")
async def delete_field(
    field_id: int,
    current_user: dict = Depends(get_current_user)
):
    # Check if field exists and belongs to user
    check_query = """
        SELECT field_id FROM recommendation_fields
        WHERE field_id = :field_id AND user_id = :user_id
    """
    field = await database.fetch_one(
        query=check_query, 
        values={"field_id": field_id, "user_id": current_user["user_id"]}
    )
    
    if not field:
        raise HTTPException(
            status_code=404,
            detail="Field not found or you don't have permission to delete it"
        )
    
    # Delete the field
    delete_query = """
        DELETE FROM recommendation_fields
        WHERE field_id = :field_id AND user_id = :user_id
    """
    await database.execute(
        query=delete_query,
        values={"field_id": field_id, "user_id": current_user["user_id"]}
    )
    
    return {"message": "Field deleted successfully"}

# Field data endpoints
@app.post("/field-data")
async def submit_field_data(
    data: FieldDataCreate,
    current_user: dict = Depends(get_current_user)
):
    query = """
        INSERT INTO field_data 
        (field_name, location, width, length, temperature, rainfall,
         nitrogen, phosphorus, potassium, soil_ph, humidity, user_id)
        VALUES 
        (:field_name, :location, :width, :length, :temperature, :rainfall,
         :nitrogen, :phosphorus, :potassium, :soil_ph, :humidity, :user_id)
        RETURNING id
    """
    values = {
        "field_name": data.field_name,
        "location": data.location,
        "width": data.width,
        "length": data.length,
        "temperature": data.temperature,
        "rainfall": data.rainfall,
        "nitrogen": data.nitrogen,
        "phosphorus": data.phosphorus,
        "potassium": data.potassium,
        "soil_ph": data.soil_ph,
        "humidity": data.humidity,
        "user_id": current_user["user_id"]
    }
    
    result = await database.fetch_one(query=query, values=values)
    return {"field_data_id": result["id"], "message": "Field data submitted successfully"}

@app.get("/field-data/{field_name}")
async def get_field_data(
    field_name: str,
    current_user: dict = Depends(get_current_user)
):
    query = """
        SELECT id, field_name, location, width, length, temperature, rainfall,
               nitrogen, phosphorus, potassium, soil_ph, humidity, created_at
        FROM field_data
        WHERE field_name = :field_name AND user_id = :user_id
        ORDER BY created_at DESC
    """
    data = await database.fetch_all(
        query=query, 
        values={"field_name": field_name, "user_id": current_user["user_id"]}
    )
    return data

# Crop tracking endpoints
@app.post("/track-crop")
async def track_crop(
    data: TrackCropCreate,
    current_user: dict = Depends(get_current_user)
):
    # Get field_id from field_data
    field_query = """
        SELECT id FROM field_data
        WHERE field_name = :field_name AND user_id = :user_id
        ORDER BY created_at DESC
        LIMIT 1
    """
    field = await database.fetch_one(
        query=field_query,
        values={"field_name": data.field_name, "user_id": current_user["user_id"]}
    )
    
    if not field:
        raise HTTPException(
            status_code=404,
            detail=f"No field data found for field name: {data.field_name}"
        )
    
    # Insert crop tracking data
    query = """
        INSERT INTO track_crop
        (field_id, crop_planted, date_planted, notes, user_id)
        VALUES
        (:field_id, :crop_planted, :date_planted, :notes, :user_id)
        RETURNING id
    """
    values = {
        "field_id": field["id"],
        "crop_planted": data.crop_planted,
        "date_planted": data.date_planted,
        "notes": data.notes,
        "user_id": current_user["user_id"]
    }
    
    result = await database.fetch_one(query=query, values=values)
    return {"track_crop_id": result["id"], "message": "Crop tracking data saved successfully"}

@app.get("/track-crop/{field_name}")
async def get_track_crop(
    field_name: str,
    current_user: dict = Depends(get_current_user)
):
    # Get field_id from field_data
    field_query = """
        SELECT id FROM field_data
        WHERE field_name = :field_name AND user_id = :user_id
        ORDER BY created_at DESC
        LIMIT 1
    """
    field = await database.fetch_one(
        query=field_query,
        values={"field_name": field_name, "user_id": current_user["user_id"]}
    )
    
    if not field:
        return []
    
    # Get crop tracking data
    query = """
        SELECT id, field_id, crop_planted, date_planted, notes, created_at
        FROM track_crop
        WHERE field_id = :field_id AND user_id = :user_id
        ORDER BY created_at DESC
    """
    data = await database.fetch_all(
        query=query,
        values={"field_id": field["id"], "user_id": current_user["user_id"]}
    )
    
    return data

@app.get("/all-crops")
async def get_all_crops(current_user: dict = Depends(get_current_user)):
    query = """
        SELECT tc.id, tc.field_id, tc.crop_planted, tc.date_planted, tc.notes, tc.created_at, fd.field_name
        FROM track_crop tc
        JOIN field_data fd ON tc.field_id = fd.id
        WHERE tc.user_id = :user_id
        ORDER BY tc.created_at DESC
    """
    data = await database.fetch_all(query=query, values={"user_id": current_user["user_id"]})
    return data

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
