from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_cors import CORS
import psycopg2
from psycopg2 import sql
from datetime import datetime, timedelta
import jwt
from functools import wraps
import os

app = Flask(__name__)
# Updated CORS configuration to be more permissive for testing
CORS(app, resources={r"/*": {"origins": "*"}})

# JWT Configuration - should match your FastAPI auth.py settings
SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"

# Database configuration
DB_CONFIG = {
    "dbname": "agroaidatabase",
    "user": "postgres",
    "password": "thatohatsi",
    "host": "localhost"
}

def get_db_connection():
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        return conn
    except Exception as e:
        print(f"Database connection error: {e}")
        raise

# Authentication decorator for Flask routes
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        auth_header = request.headers.get('Authorization')
        
        if auth_header:
            # Extract token from "Bearer <token>"
            parts = auth_header.split()
            if len(parts) == 2 and parts[0].lower() == 'bearer':
                token = parts[1]
        
        if not token:
            return jsonify({'status': 'error', 'message': 'Token is missing'}), 401
        
        try:
            # Decode the token
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            user_email = payload.get('sub')
            
            # Get user_id from the database
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT user_id FROM users WHERE email = %s", (user_email,))
            user_result = cursor.fetchone()
            conn.close()
            
            if not user_result:
                return jsonify({'status': 'error', 'message': 'Invalid user'}), 401
            
            # Add user_id to kwargs so it can be used in the route function
            kwargs['user_id'] = user_result[0]
            
        except jwt.ExpiredSignatureError:
            return jsonify({'status': 'error', 'message': 'Token has expired'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'status': 'error', 'message': 'Invalid token'}), 401
        except Exception as e:
            return jsonify({'status': 'error', 'message': str(e)}), 500
        
        return f(*args, **kwargs)
    
    return decorated

# Serve static files
@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('.', path)

@app.route('/')
def index():
    return send_from_directory('.', 'landing_page.html')

@app.route('/login', methods=['GET', 'POST'])
def login_page():
    if request.method == 'GET':
        return send_from_directory('.', 'login.html')
    elif request.method == 'POST':
        print("Received login request")
        
        try:
            # Get JSON data
            json_data = request.get_json()
            
            if not json_data:
                print("No JSON data received")
                return jsonify({"detail": "Invalid request format. JSON data required."}), 415
            
            username = json_data.get('username')
            password = json_data.get('password')
            
            print(f"Login attempt for username: {username}")
            
            if not username or not password:
                print("Missing username or password")
                return jsonify({"detail": "Username and password are required"}), 401
            
            # Connect to database
            conn = get_db_connection()
            cursor = conn.cursor()
            
            # Check if user exists
            cursor.execute("SELECT user_id, email, full_name, password_hash FROM users WHERE email = %s", (username,))
            user = cursor.fetchone()
            
            if not user:
                print(f"User not found: {username}")
                return jsonify({"detail": "Invalid username or password"}), 401
            
            user_id, email, full_name, hashed_password = user
            
            # For development purposes - direct comparison
            # In production, use proper password verification
            if password != hashed_password:
                print("Password mismatch")
                return jsonify({"detail": "Invalid username or password"}), 401
            
            # Generate JWT token
            access_token_expires = datetime.utcnow() + timedelta(minutes=30)
            to_encode = {
                "sub": email,
                "exp": access_token_expires
            }
            access_token = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
            
            # Return token and user info
            return jsonify({
                "access_token": access_token,
                "token_type": "bearer",
                "user_id": user_id,
                "email": email,
                "full_name": full_name
            })
            
        except Exception as e:
            print(f"Login error: {e}")
            import traceback
            traceback.print_exc()
            return jsonify({"detail": f"Login failed: {str(e)}"}), 401
        finally:
            if 'conn' in locals():
                conn.close()
                
@app.route('/debug-users', methods=['GET'])
def debug_users():
    """Endpoint to check stored users (for debugging only)"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all users with limited password info
        cursor.execute("SELECT user_id, email, full_name, LEFT(password_hash, 3) || '...' || RIGHT(password_hash, 3), LENGTH(password_hash) FROM users LIMIT 10")
        users = cursor.fetchall()
        
        # Convert to list of dictionaries
        result = []
        for user in users:
            result.append({
                'user_id': user[0],
                'email': user[1],
                'full_name': user[2],
                'password_preview': user[3],
                'password_length': user[4]
            })
        
        return jsonify(result), 200
    except Exception as e:
        print(f"Error in debug-users: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')
        full_name = data.get('full_name')
        
        if not email or not password or not full_name:
            return jsonify({"detail": "Email, password, and full name are required"}), 400
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if user already exists
        cursor.execute("SELECT user_id FROM users WHERE email = %s", (email,))
        if cursor.fetchone():
            return jsonify({"detail": "User with this email already exists"}), 400
        
        # Create users table if it doesn't exist
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id SERIAL PRIMARY KEY,
                email VARCHAR(100) UNIQUE NOT NULL,
                password_hash VARCHAR(100) NOT NULL,
                full_name VARCHAR(100) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        
        # Insert new user
        cursor.execute(
            "INSERT INTO users (email, password_hash, full_name) VALUES (%s, %s, %s) RETURNING user_id",
            (email, password, full_name)
        )
        user_id = cursor.fetchone()[0]
        conn.commit()
        
        # Generate JWT token for automatic login
        access_token_expires = datetime.utcnow() + timedelta(minutes=30)
        to_encode = {
            "sub": email,
            "exp": access_token_expires
        }
        access_token = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
        
        # Return token and user info
        return jsonify({
            "access_token": access_token,
            "token_type": "bearer",
            "user_id": user_id,
            "email": email,
            "full_name": full_name
        })
        
    except Exception as e:
        print(f"Registration error: {e}")
        return jsonify({"detail": f"Registration failed: {str(e)}"}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/dashboard')
def dashboard():
    return send_from_directory('templates', 'PlayingAgroAI.html')

# Ensure tables have user_id column
def ensure_user_id_column(table_name, conn, cursor):
    # Check if user_id column exists
    cursor.execute(f"""
        SELECT EXISTS (
            SELECT FROM information_schema.columns 
            WHERE table_schema = 'public'
            AND table_name = '{table_name}'
            AND column_name = 'user_id'
        );
    """)
    
    column_exists = cursor.fetchone()[0]
    
    if not column_exists:
        print(f"Adding user_id column to {table_name}")
        cursor.execute(f"""
            ALTER TABLE {table_name} 
            ADD COLUMN user_id INTEGER;
        """)
        conn.commit()

@app.route('/submit-field', methods=['POST'])
@token_required
def submit_field(user_id):
    data = request.get_json()

    if not data:
        return jsonify({
            "status": "error",
            "message": "No data provided"
        }), 400

    # Validate required fields
    required_fields = ['field_name', 'length', 'width', 'location']
    for field in required_fields:
        if field not in data:
            return jsonify({
                "status": "error",
                "message": f"Missing required field: {field}"
            }), 400

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if table exists, create if it doesn't
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_schema = 'public'
                AND table_name = 'recommendation_fields'
            );
        """)
        
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            cursor.execute("""
                CREATE TABLE recommendation_fields (
                    field_id SERIAL PRIMARY KEY,
                    field_name VARCHAR(100) NOT NULL,
                    length FLOAT NOT NULL,
                    width FLOAT NOT NULL,
                    location VARCHAR(255) NOT NULL,
                    user_id INTEGER
                );
            """)
            conn.commit()
            print("Created recommendation_fields table with user_id column")
        else:
            # Ensure user_id column exists
            ensure_user_id_column('recommendation_fields', conn, cursor)
        
        # Insert data with field_id as the primary key and user_id
        query = sql.SQL("""
            INSERT INTO recommendation_fields (field_name, length, width, location, user_id)
            VALUES (%s, %s, %s, %s, %s)
            RETURNING field_id
        """)
        
        cursor.execute(query, (
            data['field_name'],
            float(data['length']),
            float(data['width']),
            data['location'],
            user_id  # Add user_id to associate with the current user
        ))
        
        field_id = cursor.fetchone()[0]
        conn.commit()
        
        print(f"Field added successfully with ID: {field_id} for user: {user_id}")
        
        return jsonify({
            "status": "success",
            "message": "Field data saved successfully",
            "field_id": field_id
        }), 201
        
    except Exception as e:
        print(f"Error in submit_field: {e}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500
        
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/submit-field-data', methods=['POST'])
@token_required
def submit_field_data(user_id):
    data = request.get_json()

    if not data:
        return jsonify({
            "status": "error",
            "message": "No data provided"
        }), 400

    # Validate required fields
    required_fields = ['field_name', 'location', 'width', 'length', 'temperature', 
                       'rainfall', 'nitrogen', 'phosphorus', 'potassium', 'soil_ph', 'humidity']

    for field in required_fields:
        if field not in data:
            return jsonify({
                "status": "error",
                "message": f"Missing required field: {field}"
            }), 400

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if field_data table exists, create if it doesn't
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_schema = 'public'
                AND table_name = 'field_data'
            );
        """)
        
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            cursor.execute("""
                CREATE TABLE field_data (
                    id SERIAL PRIMARY KEY,
                    field_name VARCHAR(100) NOT NULL,
                    location VARCHAR(255) NOT NULL,
                    width FLOAT NOT NULL,
                    length FLOAT NOT NULL,
                    temperature FLOAT NOT NULL,
                    rainfall FLOAT NOT NULL,
                    nitrogen INTEGER NOT NULL,
                    phosphorus INTEGER NOT NULL,
                    potassium INTEGER NOT NULL,
                    soil_ph FLOAT NOT NULL,
                    humidity FLOAT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    user_id INTEGER
                );
            """)
            conn.commit()
            print("Created field_data table with user_id column")
        else:
            # Ensure user_id column exists
            ensure_user_id_column('field_data', conn, cursor)
        
        # Insert data into field_data table with user_id
        query = sql.SQL("""
            INSERT INTO field_data (
                field_name, location, width, length, temperature, rainfall,
                nitrogen, phosphorus, potassium, soil_ph, humidity, user_id
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
        """)
        
        cursor.execute(query, (
            data['field_name'],
            data['location'],
            float(data['width']),
            float(data['length']),
            float(data['temperature']),
            float(data['rainfall']),
            int(data['nitrogen']),
            int(data['phosphorus']),
            int(data['potassium']),
            float(data['soil_ph']),
            float(data['humidity']),
            user_id  # Add user_id to associate with the current user
        ))
        
        field_data_id = cursor.fetchone()[0]
        conn.commit()
        
        print(f"Field data added successfully with ID: {field_data_id} for user: {user_id}")
        
        return jsonify({
            "status": "success",
            "message": "Field data saved successfully",
            "field_data_id": field_data_id
        }), 201
        
    except Exception as e:
        print(f"Error in submit_field_data: {e}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500
        
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/submit-track-crop', methods=['POST'])
@token_required
def submit_track_crop(user_id):
    data = request.get_json()

    if not data:
        return jsonify({
            "status": "error",
            "message": "No data provided"
        }), 400

    # Validate required fields
    required_fields = ['field_name', 'crop_planted', 'date_planted']

    for field in required_fields:
        if field not in data:
            return jsonify({
                "status": "error",
                "message": f"Missing required field: {field}"
            }), 400

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if track_crop table exists, create if it doesn't
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_schema = 'public'
                AND table_name = 'track_crop'
            );
        """)
        
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            cursor.execute("""
                CREATE TABLE track_crop (
                    id SERIAL PRIMARY KEY,
                    field_id INTEGER,
                    crop_planted VARCHAR(100) NOT NULL,
                    date_planted DATE NOT NULL,
                    notes TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    user_id INTEGER,
                    FOREIGN KEY (field_id) REFERENCES field_data(id) ON DELETE CASCADE
                );
            """)
            conn.commit()
            print("Created track_crop table with user_id column")
        else:
            # Ensure user_id column exists
            ensure_user_id_column('track_crop', conn, cursor)
        
        # Get field_id from field_data table based on field_name and user_id
        cursor.execute("""
            SELECT id FROM field_data 
            WHERE field_name = %s AND user_id = %s
            ORDER BY created_at DESC 
            LIMIT 1
        """, (data['field_name'], user_id))
        
        field_id_result = cursor.fetchone()
        
        if not field_id_result:
            return jsonify({
                "status": "error",
                "message": f"No field data found for field name: {data['field_name']}"
            }), 404
        
        field_id = field_id_result[0]
        
        # Insert data into track_crop table with user_id
        query = sql.SQL("""
            INSERT INTO track_crop (
                field_id, crop_planted, date_planted, notes, user_id
            )
            VALUES (%s, %s, %s, %s, %s)
            RETURNING id
        """)
        
        cursor.execute(query, (
            field_id,
            data['crop_planted'],
            data['date_planted'],
            data.get('notes', ''),  # Notes is optional
            user_id  # Add user_id to associate with the current user
        ))
        
        track_crop_id = cursor.fetchone()[0]
        conn.commit()
        
        print(f"Crop tracking data added successfully with ID: {track_crop_id} for user: {user_id}")
        
        return jsonify({
            "status": "success",
            "message": "Crop tracking data saved successfully",
            "track_crop_id": track_crop_id
        }), 201
        
    except Exception as e:
        print(f"Error in submit_track_crop: {e}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500
        
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/track-crop/<field_name>', methods=['GET'])
@token_required
def get_track_crop(field_name, user_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if track_crop table exists
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_schema = 'public'
                AND table_name = 'track_crop'
            );
        """)
        
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            return jsonify([]), 200
        
        # Get field_id from field_data table based on field_name and user_id
        cursor.execute("""
            SELECT id FROM field_data 
            WHERE field_name = %s AND user_id = %s
            ORDER BY created_at DESC 
            LIMIT 1
        """, (field_name, user_id))
        
        field_id_result = cursor.fetchone()
        
        if not field_id_result:
            return jsonify([]), 200
        
        field_id = field_id_result[0]
        
        # Get crop tracking data for the field and user
        cursor.execute("""
            SELECT id, field_id, crop_planted, date_planted, notes, created_at
            FROM track_crop
            WHERE field_id = %s AND user_id = %s
            ORDER BY created_at DESC
        """, (field_id, user_id))
        
        track_crop_data = cursor.fetchall()
        
        # Convert to list of dictionaries
        result = []
        for data in track_crop_data:
            result.append({
                'id': data[0],
                'field_id': data[1],
                'crop_planted': data[2],
                'date_planted': data[3].isoformat() if data[3] else None,
                'notes': data[4] if data[4] else '',
                'created_at': data[5].isoformat() if data[5] else None
            })
            
        return jsonify(result), 200
        
    except Exception as e:
        print(f"Error in get_track_crop: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/all-crops', methods=['GET'])
@token_required
def get_all_crops(user_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if track_crop table exists
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_schema = 'public'
                AND table_name = 'track_crop'
            );
        """)
        
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            print("track_crop table does not exist")
            return jsonify([]), 200
        
        # Get all crop tracking data with field names for the current user
        cursor.execute("""
            SELECT tc.id, tc.field_id, tc.crop_planted, tc.date_planted, tc.notes, tc.created_at, fd.field_name
            FROM track_crop tc
            JOIN field_data fd ON tc.field_id = fd.id
            WHERE tc.user_id = %s
            ORDER BY tc.created_at DESC
        """, (user_id,))
        
        track_crop_data = cursor.fetchall()
        print(f"Found {len(track_crop_data)} crop records for user: {user_id}")
        
        # Convert to list of dictionaries
        result = []
        for data in track_crop_data:
            result.append({
                'id': data[0],
                'field_id': data[1],
                'crop_planted': data[2],
                'date_planted': data[3].isoformat() if data[3] else None,
                'notes': data[4] if data[4] else '',
                'created_at': data[5].isoformat() if data[5] else None,
                'field_name': data[6]
            })
            
        return jsonify(result), 200
        
    except Exception as e:
        print(f"Error in get_all_crops: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/update-track-crop/<int:track_crop_id>', methods=['PUT'])
@token_required
def update_track_crop(track_crop_id, user_id):
    data = request.get_json()

    if not data:
        return jsonify({
            "status": "error",
            "message": "No data provided"
        }), 400

    # Validate required fields
    required_fields = ['crop_planted', 'date_planted']

    for field in required_fields:
        if field not in data:
            return jsonify({
                "status": "error",
                "message": f"Missing required field: {field}"
            }), 400

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if track_crop record exists and belongs to the user
        cursor.execute("SELECT id FROM track_crop WHERE id = %s AND user_id = %s", (track_crop_id, user_id))
        record = cursor.fetchone()
        
        if not record:
            return jsonify({
                "status": "error",
                "message": f"No crop tracking record found with ID: {track_crop_id} for this user"
            }), 404
        
        # Update data in track_crop table
        query = sql.SQL("""
            UPDATE track_crop 
            SET crop_planted = %s, date_planted = %s, notes = %s
            WHERE id = %s AND user_id = %s
            RETURNING id
        """)
        
        cursor.execute(query, (
            data['crop_planted'],
            data['date_planted'],
            data.get('notes', ''),  # Notes is optional
            track_crop_id,
            user_id
        ))
        
        updated_id = cursor.fetchone()[0]
        conn.commit()
        
        print(f"Crop tracking data updated successfully with ID: {updated_id} for user: {user_id}")
        
        return jsonify({
            "status": "success",
            "message": "Crop tracking data updated successfully",
            "track_crop_id": updated_id
        }), 200
        
    except Exception as e:
        print(f"Error in update_track_crop: {e}")
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500
        
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/track-crop-by-id/<int:track_crop_id>', methods=['GET'])
@token_required
def get_track_crop_by_id(track_crop_id, user_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Add more detailed logging
        print(f"Fetching crop tracking record with ID: {track_crop_id} for user: {user_id}")
        
        # First check if the record exists and belongs to the user
        cursor.execute("SELECT COUNT(*) FROM track_crop WHERE id = %s AND user_id = %s", (track_crop_id, user_id))
        count = cursor.fetchone()[0]
        
        if count == 0:
            print(f"No crop tracking record found with ID: {track_crop_id} for user: {user_id}")
            return jsonify({
                "status": "error",
                "message": f"No crop tracking record found with ID: {track_crop_id} for this user"
            }), 404
        
        # Get the specific crop tracking record
        cursor.execute("""
            SELECT id, field_id, crop_planted, date_planted, notes, created_at
            FROM track_crop
            WHERE id = %s AND user_id = %s
        """, (track_crop_id, user_id))
        
        record = cursor.fetchone()
        
        # Convert to dictionary
        result = {
            'id': record[0],
            'field_id': record[1],
            'crop_planted': record[2],
            'date_planted': record[3].isoformat() if record[3] else None,
            'notes': record[4] if record[4] else '',
            'created_at': record[5].isoformat() if record[5] else None
        }
        
        print(f"Successfully fetched crop tracking record: {result}")
        return jsonify(result), 200
        
    except Exception as e:
        print(f"Error in get_track_crop_by_id: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/fields', methods=['GET'])
@token_required
def get_fields(user_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if table exists
        cursor.execute("""
            SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_schema = 'public'
                AND table_name = 'recommendation_fields'
            );
        """)
        
        table_exists = cursor.fetchone()[0]
        
        if not table_exists:
            return jsonify([]), 200
        
        # Get fields for the current user only
        cursor.execute("SELECT * FROM recommendation_fields WHERE user_id = %s", (user_id,))
        fields = cursor.fetchall()
        
        # Convert to list of dictionaries
        result = []
        for field in fields:
            result.append({
                'field_id': field[0],
                'field_name': field[1],
                'length': field[2],
                'width': field[3],
                'location': field[4]
            })
            
        return jsonify(result), 200
        
    except Exception as e:
        print(f"Error in get_fields: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/fields/<int:field_id>', methods=['DELETE'])
@token_required
def delete_field(field_id, user_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if field exists and belongs to the user
        cursor.execute("SELECT field_name FROM recommendation_fields WHERE field_id = %s AND user_id = %s", 
                      (field_id, user_id))
        deleted_field = cursor.fetchone()
        
        if not deleted_field:
            return jsonify({'status': 'error', 'message': 'Field not found or you do not have permission to delete it'}), 404
            
        # Delete the field
        cursor.execute("DELETE FROM recommendation_fields WHERE field_id = %s AND user_id = %s", 
                      (field_id, user_id))
        conn.commit()
        
        return jsonify({'status': 'success', 'message': f"Field '{deleted_field[0]}' deleted"}), 200
        
    except Exception as e:
        print(f"Error in delete_field: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/health', methods=['GET'])
def health_check():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT 1')
        return jsonify({'status': 'healthy', 'database': 'connected'}), 200
    except Exception as e:
        return jsonify({'status': 'unhealthy', 'database': 'disconnected', 'error': str(e)}), 500
    finally:
        if 'conn' in locals():
            conn.close()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
