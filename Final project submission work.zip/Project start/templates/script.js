// API base URL
const API_BASE = "http://localhost:5000";

// Auth utilities
const Auth = {
    // Get token from localStorage
    getToken: function() {
        return localStorage.getItem("auth_token");
    },
    
    // Check if user is authenticated
    isAuthenticated: function() {
        return !!this.getToken();
    },
    
    // Log out user
    logout: function() {
        localStorage.removeItem("auth_token");
        localStorage.removeItem("user_id");
        localStorage.removeItem("user_email");
        localStorage.removeItem("user_name");
        localStorage.removeItem("token_type");
        window.location.href = "/login.html";
    },
    
    // Show authentication error message
    showError: function(message = "You need to be logged in to use this feature.") {
        const authErrorMessage = document.getElementById('authErrorMessage');
        if (authErrorMessage) {
            authErrorMessage.textContent = message;
            authErrorMessage.style.display = 'block';
            
            // Hide after 5 seconds
            setTimeout(() => {
                authErrorMessage.style.display = 'none';
            }, 5000);
        } else {
            alert(message);
        }
    }
};

// API request function (not using recursion)
async function apiRequest(url, options = {}) {
    // Don't use authenticatedFetch here to avoid recursion
    const token = Auth.getToken();
    
    const headers = new Headers(options.headers || {});
    if (token) {
        headers.set('Authorization', `Bearer ${token}`);
    }
    
    if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
        headers.set('Content-Type', 'application/json');
    }
    
    try {
        const response = await fetch(url.startsWith('http') ? url : `${API_BASE}${url}`, {
            ...options,
            headers
        });
        
        if (response.status === 401) {
            Auth.showError("Your session has expired. Please log in again.");
            // Optional: Auto logout on 401
            // Auth.logout();
            throw new Error("Unauthorized: Session expired");
        }
        
        return response;
    } catch (error) {
        console.error("API request failed:", error);
        throw error;
    }
}
// Enable debug mode for development
const DEBUG = false;

// Debug function
function debug(message, data = null) {
    if (!DEBUG) return;
    
    const debugPanel = document.getElementById('debugPanel');
    if (!debugPanel) return;
    
    debugPanel.style.display = 'block';
    
    const timestamp = new Date().toLocaleTimeString();
    let logMessage = `[${timestamp}] ${message}`;
    
    if (data) {
        try {
            logMessage += `: ${JSON.stringify(data)}`;
        } catch (e) {
            logMessage += `: [Object cannot be stringified]`;
        }
    }
    
    const logEntry = document.createElement('div');
    logEntry.textContent = logMessage;
    debugPanel.appendChild(logEntry);
    
    // Limit entries
    while (debugPanel.children.length > 20) {
        debugPanel.removeChild(debugPanel.firstChild);
    }
    
    // Auto-scroll to bottom
    debugPanel.scrollTop = debugPanel.scrollHeight;
    
    // Also log to console
    console.log(message, data || '');
}

document.addEventListener('DOMContentLoaded', function() {
    debug('Application initialized');
    
    // Display user name in header
    const userName = localStorage.getItem("user_name");
    
    if (userName) {
        document.getElementById("userName").textContent = userName;
    } else {
        document.getElementById("userName").textContent = "Guest";
    }
    
    // Initialize the application
    setActiveTab('overview');
    generateRandomValues();
    
    // Set up event listeners
    setupEventListeners();
    
    // Initialize map
    initializeMap();
    
    // Initialize charts
    initializeCharts();
    
    // Load fields from database to dropdown
    loadFieldsToDropdown();
    
    // Try to display fields from the backend
    displayFields();
    
    // Load all crops for the overview section
    loadAllCrops();

    // Add field modal functionality
    const addFieldBtn = document.getElementById('addFieldBtn');
    const addFieldModal = document.getElementById('addFieldModal');
    const closeModalBtn = document.getElementById('closeModalBtn');

    if (addFieldBtn && addFieldModal && closeModalBtn) {
        addFieldBtn.addEventListener('click', function() {
            addFieldModal.classList.add('active');
        });

        closeModalBtn.addEventListener('click', function() {
            addFieldModal.classList.remove('active');
        });

        // Close modal when clicking outside the content
        addFieldModal.addEventListener('click', function(e) {
            if (e.target === addFieldModal) {
                addFieldModal.classList.remove('active');
            }
        });
    }
});

// Function to load all crops for the overview section
async function loadAllCrops() {
    debug('Loading all crops for overview');
    
    try {
        const response = await authenticatedFetch('http://localhost:5000/all-crops');
        debug('Fetch all crops response status', response.status);
        
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        
        const cropsData = await response.json();
        debug('Fetched all crops data', cropsData);
        
        // Update the overview section with the crops data
        updateOverviewCrops(cropsData);
    } catch (error) {
        debug('Error loading all crops', error);
        console.error('Error loading all crops:', error);
        
        // Show a message if there was an error
        const noCropsMessage = document.getElementById('noCropsMessage');
        if (noCropsMessage) {
            noCropsMessage.style.display = 'block';
        }
    }
}

// Function to update the overview section with crops data
function updateOverviewCrops(cropsData) {
    debug('Updating overview crops', cropsData);
    
    const cropProgressCards = document.getElementById('cropProgressCards');
    
    // Clear existing cards except the no crops message
    const noCropsMessage = document.getElementById('noCropsMessage');
    cropProgressCards.innerHTML = '';
    cropProgressCards.appendChild(noCropsMessage);
    
    if (!cropsData || cropsData.length === 0) {
        debug('No crops data available');
        noCropsMessage.style.display = 'block';
        return;
    }
    
    // Hide the no crops message since we have data
    noCropsMessage.style.display = 'none';
    
    // Get unique crops (in case there are multiple entries for the same crop)
    const uniqueCrops = [];
    const processedFields = new Set();
    
    cropsData.forEach(crop => {
        const fieldCropKey = `${crop.field_name}_${crop.crop_planted}`;
        if (!processedFields.has(fieldCropKey)) {
            uniqueCrops.push(crop);
            processedFields.add(fieldCropKey);
        }
    });
    
    debug('Unique crops to display', uniqueCrops);
    
    // Create a card for each unique crop
    uniqueCrops.forEach((crop, index) => {
        // Calculate growth percentage
        const growthPercentage = calculateGrowthPercentage(crop.date_planted, crop.crop_planted);
        
        // Get crop emoji
        const cropEmoji = getCropEmoji(crop.crop_planted);
        
        // Create the card
        const card = document.createElement('div');
        card.className = 'progress-card' + (index % 2 === 1 ? ' light' : '');
        
        card.innerHTML = `
            <div class="progress-icon">${cropEmoji}</div>
            <h3>${crop.crop_planted}</h3>
            <p>${growthPercentage}% Growth</p>
            <small>Field: ${crop.field_name}</small>
        `;
        
        cropProgressCards.appendChild(card);
    });
    
    // Update the growth chart with the new data
    updateGrowthChart(uniqueCrops);
}

// Function to calculate growth percentage based on planting date and crop type
function calculateGrowthPercentage(plantingDate, cropType) {
    debug('Calculating growth percentage', { plantingDate, cropType });
    
    // Get the current day since planting
    const currentDay = calculateCurrentDay(plantingDate);
    
    // Get the expected duration for this crop type
    let duration = 120; // Default duration
    
    if (cropType === "Maize") {
        duration = 140;
    } else if (cropType === "Wheat") {
        duration = 120;
    } else if (cropType === "Potatoes") {
        duration = 110;
    } else if (cropType === "Rice") {
        duration = 130;
    } else if (cropType === "Beans") {
        duration = 90;
    } else if (cropType === "Tomatoes") {
        duration = 100;
    }
    
    // Calculate percentage
    let percentage = Math.round((currentDay / duration) * 100);
    
    // Cap at 100%
    if (percentage > 100) percentage = 100;
    
    return percentage;
}

// Function to get an emoji for each crop type
function getCropEmoji(cropType) {
    switch (cropType) {
        case "Maize":
            return "🌽";
        case "Wheat":
            return "🌾";
        case "Potatoes":
            return "🥔";
        case "Rice":
            return "🍚";
        case "Beans":
            return "🌱";
        case "Tomatoes":
            return "🍅";
        default:
            return "🌿";
    }
}

// Function to update the growth chart with actual crop data
function updateGrowthChart(cropsData) {
    debug('Updating growth chart', cropsData);
    
    // If there's no data, don't update the chart
    if (!cropsData || cropsData.length === 0) return;
    
    const ctx = document.getElementById('growthChart').getContext('2d');
    
    // Destroy existing chart if it exists
    if (window.growthChart) {
        window.growthChart.destroy();
    }
    
    // Prepare data for the chart
    const labels = [];
    const datasets = [];
    const colors = ['#1B4D3E', '#27AE60', '#F39C12', '#E74C3C', '#3498DB', '#9B59B6'];
    
    // Create a dataset for each crop
    cropsData.forEach((crop, index) => {
        const growthPercentage = calculateGrowthPercentage(crop.date_planted, crop.crop_planted);
        const colorIndex = index % colors.length;
        
        // Add the crop to labels if it's not already there
        if (!labels.includes(crop.crop_planted)) {
            labels.push(crop.crop_planted);
        }
        
        // Create a dataset for this crop
        datasets.push({
            label: `${crop.crop_planted} (${crop.field_name})`,
            data: [growthPercentage],
            backgroundColor: colors[colorIndex],
            borderColor: colors[colorIndex],
            borderWidth: 1
        });
    });
    
    // Create the chart
    window.growthChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Growth Percentage'],
            datasets: datasets
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                        display: true,
                        text: 'Growth Percentage'
                    }
                }
            },
            plugins: {
                title: {
                    display: true,
                    text: 'Crop Growth Comparison'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${context.raw}%`;
                        }
                    }
                }
            }
        }
    });
}

// Function to load fields from database and populate dropdown
async function loadFieldsToDropdown() {
    debug('Loading fields to dropdown');
    
    try {
        const response = await authenticatedFetch('http://localhost:5000/fields');
        debug('Fetch fields for dropdown response status', response.status);
        
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        
        const fieldsData = await response.json();
        debug('Fetched fields for dropdown', fieldsData);
        
        // Clear existing options except the first one (Select a field)
        const fieldSelect = document.getElementById('fieldSelect');
        while (fieldSelect.options.length > 1) {
            fieldSelect.remove(1);
        }
        
        // Add fields from database to dropdown
        fieldsData.forEach(field => {
            const option = document.createElement('option');
            option.value = field.field_name;
            option.textContent = field.field_name;
            fieldSelect.appendChild(option);
        });
        
        debug('Fields loaded to dropdown successfully');
    } catch (error) {
        debug('Error loading fields to dropdown', error);
        console.error('Error loading fields to dropdown:', error);
        showMessage('Error loading fields: ' + error.message, 'error');
    }
}

function setupEventListeners() {
    debug('Setting up event listeners');
    
    // Field selection change
    const fieldSelect = document.getElementById('fieldSelect');
    fieldSelect.addEventListener('change', function() {
        const fieldName = this.value;
        debug('Field selected', fieldName);
        updateFieldInfo(fieldName);
        loadCropAssignment(fieldName);
        updateTrackCropSection(fieldName);
        
        // MODIFIED: Removed the automatic tab switching when a field is selected
        // if (fieldName) {
        //     setActiveTab('trackCrop');
        // }
    });
    
    // Field form submission
    document.getElementById('fieldForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        debug('Field form submitted');
        
        const fieldName = document.getElementById('fieldName').value.trim();
        const location = document.getElementById('fieldLocation').value.trim();
        const length = parseFloat(document.getElementById('fieldLength').value);
        const width = parseFloat(document.getElementById('fieldWidth').value);
        const temperature = parseFloat(document.getElementById('temperature').value);
        const rainfall = parseFloat(document.getElementById('rainfall').value);
        const nitrogen = parseInt(document.getElementById('N').value);
        const phosphorus = parseInt(document.getElementById('P').value);
        const potassium = parseInt(document.getElementById('K').value);
        const soil_ph = parseFloat(document.getElementById('ph').value);
        const humidity = parseFloat(document.getElementById('humidity').value);
        
        // Basic validation
        if (!fieldName || !location) {
            showMessage('Please fill in all required fields', 'error');
            return;
        }
        
        const formData = {
            field_name: fieldName,
            location: location,
            length: length,
            width: width,
            temperature: temperature,
            rainfall: rainfall,
            nitrogen: nitrogen,
            phosphorus: phosphorus,
            potassium: potassium,
            soil_ph: soil_ph,
            humidity: humidity
        };
        
        debug('Saving field data and generating recommendation', formData);
        
        try {
            // First, save the field data to the database
            const saveResponse = await authenticatedFetch('http://localhost:5000/submit-field-data', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });
            
            debug('Save field data response status', saveResponse.status);
            
            const saveResult = await saveResponse.json();
            debug('Save field data response', saveResult);
            
            if (saveResponse.ok) {
                showMessage('Field data saved successfully!', 'success');
                
                // Now generate the recommendation
                const data = {
                    N: nitrogen,
                    P: phosphorus,
                    K: potassium,
                    temperature: temperature,
                    humidity: humidity,
                    ph: soil_ph,
                    rainfall: rainfall
                };
                
                // For demo purposes, we'll simulate a response
                const mockRecommendation = {
                    recommended_crop: ["Maize", "Rice", "Wheat", "Potatoes"][Math.floor(Math.random() * 4)],
                };
                
                showRecommendation(mockRecommendation.recommended_crop, data);
            } else {
                throw new Error(saveResult.message || 'Failed to save field data');
            }
        } catch (error) {
            debug('Error in field form submission', error);
            console.error('Error:', error);
            showMessage(`Error: ${error.message}`, 'error');
        }
    });
    
    // Add field form submission
    document.getElementById('addFieldForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        debug('Add field form submitted');
        
        const newFieldName = document.getElementById('newFieldName').value.trim();
        const newFieldLength = parseFloat(document.getElementById('newFieldLength').value);
        const newFieldWidth = parseFloat(document.getElementById('newFieldWidth').value);
        const newFieldLocation = document.getElementById('newFieldLocation').value.trim();
        
        // Basic validation
        if (!newFieldName || !newFieldLocation) {
            showMessage('Please fill in all required fields', 'error');
            return;
        }

        if (isNaN(newFieldLength) || isNaN(newFieldWidth) || newFieldLength <= 0 || newFieldWidth <= 0) {
            showMessage('Please enter valid dimensions', 'error');
            return;
        }
        
        const formData = {
            field_name: newFieldName,
            length: newFieldLength,
            width: newFieldWidth,
            location: newFieldLocation
        };

        debug('Add field form data', formData);
        
        try {
            const response = await authenticatedFetch('http://localhost:5000/submit-field', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });

            debug('Add field response status', response.status);
            
            const result = await response.json();
            debug('Add field response data', result);
            
            if (response.ok) {
                showMessage(`Field added successfully! ID: ${result.field_id}`, 'success');
                this.reset(); // Clear the form
                
                // Refresh the field list
                displayFields();
                
                // Reload fields in dropdown
                loadFieldsToDropdown();
            } else {
                throw new Error(result.message || 'Failed to add field');
            }
        } catch (error) {
            debug('Error adding field', error);
            console.error('Error adding field:', error);
            showMessage(`Error: ${error.message}`, 'error');
        }
    });

    // Crop assignment form
    document.getElementById('assignCropForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        debug('Crop assignment form submitted');

        const fieldName = document.getElementById('fieldSelect').value;
        const crop = document.getElementById('cropSelect').value;
        const startDate = document.getElementById('startDateInput').value;
        const notes = document.getElementById('cropNotes').value.trim();

        if (!fieldName || !crop || !startDate) {
            showTrackCropMessage("Please select a field, crop, and start date.", 'error');
            return;
        }

        const formData = {
            field_name: fieldName,
            crop_planted: crop,
            date_planted: startDate,
            notes: notes
        };

        debug('Saving crop tracking data', formData);
        
        try {
            const response = await authenticatedFetch('http://localhost:5000/submit-track-crop', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });
            
            debug('Save crop tracking data response status', response.status);
            
            const result = await response.json();
            debug('Save crop tracking data response', result);
            
            if (response.ok) {
                showTrackCropMessage('Crop tracking data saved successfully!', 'success');
                
                // Also save to localStorage for backward compatibility
                localStorage.setItem(`crop_${fieldName}`, crop);
                localStorage.setItem(`startDate_${fieldName}`, startDate);
                
                // Update the UI
                updateTrackCropSection(fieldName);
                
                // Reload crop assignment to get the latest data
                loadCropAssignment(fieldName);
                
                // Refresh the overview section
                loadAllCrops();
            } else {
                throw new Error(result.message || 'Failed to save crop tracking data');
            }
        } catch (error) {
            debug('Error saving crop tracking data', error);
            console.error('Error saving crop tracking data:', error);
            showTrackCropMessage(`Error: ${error.message}`, 'error');
        }
    });

    // Edit crop button click - Modified to ensure it works
    document.getElementById('editCropButton').addEventListener('click', function() {
        debug('Edit crop button clicked');
        const fieldName = document.getElementById('fieldSelect').value;
        const trackCropId = document.getElementById('trackCropStatus').dataset.trackCropId;
        
        console.log('Edit button clicked');
        console.log('Field name:', fieldName);
        console.log('Track crop ID from data attribute:', trackCropId);
        
        // Force display the edit form
        showEditCropForm(fieldName);
    });

    // Cancel edit button click
    document.getElementById('cancelEditButton').addEventListener('click', function() {
        debug('Cancel edit button clicked');
        document.getElementById('editCropForm').style.display = 'none';
        
        // Show the edit button again
        document.getElementById('editCropButton').style.display = 'block';
    });

    // Update crop form submission
    document.getElementById('updateCropForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        debug('Update crop form submitted');
        
        const trackCropId = document.getElementById('editTrackCropId').value;
        const crop = document.getElementById('editCropSelect').value;
        const startDate = document.getElementById('editStartDateInput').value;
        const notes = document.getElementById('editCropNotes').value.trim();
        
        if (!crop || !startDate) {
            showEditCropMessage("Please select a crop and start date.", 'error');
            return;
        }
        
        const formData = {
            crop_planted: crop,
            date_planted: startDate,
            notes: notes
        };
        
        debug('Updating crop tracking data', { trackCropId, formData });
        
        try {
            const response = await authenticatedFetch(`http://localhost:5000/update-track-crop/${trackCropId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });
            
            debug('Update crop tracking data response status', response.status);
            
            const result = await response.json();
            debug('Update crop tracking data response', result);
            
            if (response.ok) {
                showEditCropMessage('Crop tracking data updated successfully!', 'success');
                
                // Also update localStorage for backward compatibility
                const fieldName = document.getElementById('fieldSelect').value;
                localStorage.setItem(`crop_${fieldName}`, crop);
                localStorage.setItem(`startDate_${fieldName}`, startDate);
                
                // Hide the edit form
                document.getElementById('editCropForm').style.display = 'none';
                
                // Show the edit button again
                document.getElementById('editCropButton').style.display = 'block';
                
                // Update the UI
                loadCropAssignment(fieldName);
                
                // Refresh the overview section
                loadAllCrops();
            } else {
                throw new Error(result.message || 'Failed to update crop tracking data');
            }
        } catch (error) {
            debug('Error updating crop tracking data', error);
            console.error('Error updating crop tracking data:', error);
            showEditCropMessage(`Error: ${error.message}`, 'error');
        }
    });
}

function setActiveTab(tabId) {
    debug('Setting active tab', tabId);
    
    // Hide all content areas
    document.querySelectorAll('.content-area').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show the selected content area
    document.getElementById(tabId).classList.add('active');

    // Remove active class from all nav items
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Find the nav item that corresponds to the selected tab and add the active class
    document.querySelectorAll('.nav-item').forEach(item => {
        // Create a mapping for special cases
        const tabMapping = {
            'fields': 'recommendations',
            'trackCrop': 'track crop'
        };
        
        // Get the mapped value or use the original tabId
        const mappedTabId = tabMapping[tabId] || tabId;
        
        // Convert both to lowercase for case-insensitive comparison
        if (item.textContent.toLowerCase().trim() === mappedTabId.toLowerCase().trim()) {
            item.classList.add('active');
        }
    });
}

function generateRandomValues() {
    debug('Generating random values');
    
    const temperature = Math.floor(Math.random() * 34) + 1;
    const humidity = (Math.random() * 100);
    const pH = Math.floor(Math.random() * 14);
    const nitrogen = Math.floor(Math.random() * (50 - 20)) + 20;
    const phosphorus = Math.floor(Math.random() * (20 - 10)) + 10;
    const potassium = Math.floor(Math.random() * (20 - 10)) + 10;
    const rainfall = Math.floor(Math.random() * 200) + 50;

    // Update form values
    document.getElementById('temperature').value = temperature;
    document.getElementById('humidity').value = humidity.toFixed(0);
    document.getElementById('ph').value = pH;
    document.getElementById('N').value = nitrogen;
    document.getElementById('P').value = phosphorus;
    document.getElementById('K').value = potassium;
    document.getElementById('rainfall').value = rainfall;

    // Update display values
    document.getElementById('soil-temperature').textContent = `${temperature}°C`;
    document.getElementById('soil-ph').textContent = `pH ${pH}`;
    document.getElementById('air-quality').textContent = `${(Math.random() * 100).toFixed(2)}%`;
    document.getElementById('soil-moisture').textContent = `${humidity.toFixed(2)}%`;
    document.getElementById('land-fertility').textContent = `${((nitrogen + phosphorus + potassium) / 3).toFixed(2)}%`;

    document.getElementById('real-time-temperature').textContent = `${temperature}°C`;
    document.getElementById('real-time-humidity').textContent = `${humidity.toFixed(2)}%`;
    document.getElementById('real-time-ph').textContent = pH;
    document.getElementById('real-time-light').textContent = `${(Math.random() * 1000).toFixed(2)} lux`;
}

function initializeCharts() {
    debug('Initializing charts');
    
    const ctx = document.getElementById('growthChart').getContext('2d');
    window.growthChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['April', 'May', 'June', 'July', 'August', 'September'],
            datasets: [{
                label: 'Carrots Growth',
                data: [1000, 5000, 7000, 9800, 12000, 15000],
                borderColor: '#1B4D3E',
                tension: 0.4,
                fill: false
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: '9.8K carrots'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value + 'k';
                        }
                    }
                }
            }
        }
    });
}

function initializeMap() {
    debug('Initializing map');
    
    function loadMap() {
        return new Promise((resolve) => {
            const map = L.map('map', {
                loadingControl: true
            }).setView([-29.6133, 28.2336], 8);
            
            const tileLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(map);

            tileLayer.on('load', () => {
                document.getElementById('map-loading').style.display = 'none';
                resolve(map);
            });
        });
    }

    const sensors = [
        {
            name: "National University of Lesotho",
            location: [-29.4477, 27.7428],
            status: "Active",
            type: "Environmental",
            lastReading: "10 minutes ago"
        },
        {
            name: "Lerotholi Polytechnic",
            location: [-29.3167, 27.4833],
            status: "Active",
            type: "Soil",
            lastReading: "5 minutes ago"
        },
        {
            name: "Agriculture College",
            location: [-28.8786, 28.0478],
            status: "Active",
            type: "Weather",
            lastReading: "2 minutes ago"
        }
    ];

    loadMap()
        .then(map => {
            debug('Map loaded successfully');
            
            const SensorIcon = L.divIcon({
                className: 'sensor-marker',
                html: '📍',
                iconSize: [30, 30],
                iconAnchor: [15, 30],
                popupAnchor: [0, -30]
            });

            sensors.forEach(sensor => {
                const marker = L.marker(sensor.location, {icon: SensorIcon}).addTo(map);
                
                const popupContent = `
                    <div class="sensor-popup">
                        <h3>${sensor.name}</h3>
                        <p><strong>Status:</strong> ${sensor.status}</p>
                        <p><strong>Type:</strong> ${sensor.type}</p>
                        <p><strong>Last Reading:</strong> ${sensor.lastReading}</p>
                    </div>
                `;
                
                marker.bindPopup(popupContent);
            });

            const fieldSelect = document.getElementById('fieldSelect');
            if (fieldSelect) {
                fieldSelect.addEventListener('change', function(e) {
                    const selectedField = e.target.value;
                    const sensor = sensors.find(s => s.name === selectedField);
                    
                    if (sensor) {
                        map.setView(sensor.location, 13);
                    }
                });
            }

            setTimeout(() => {
                map.invalidateSize();
            }, 100);
        })
        .catch(error => {
            debug('Error loading map', error);
            console.error('Error loading map:', error);
            document.getElementById('map-loading').textContent = 'Error loading map. Please refresh the page.';
        });
}

async function fetchFields() {
    debug('Fetching fields from server');
    
    try {
        const response = await authenticatedFetch('http://localhost:5000/fields');
        debug('Fetch fields response status', response.status);
        
        if (response.ok) {
            const data = await response.json();
            debug('Fetched fields', data);
            return data;
        } else {
            throw new Error('Failed to fetch fields');
        }
    } catch (error) {
        debug('Error fetching fields', error);
        console.error('Error fetching fields:', error);
        showMessage('Error loading fields: ' + error.message, 'error');
        return [];
    }
}

async function displayFields() {
    debug('Displaying fields');
    
    try {
        const fields = await fetchFields();
        const fieldGrid = document.getElementById('fieldGrid');
        fieldGrid.innerHTML = '';

        if (fields.length === 0) {
            fieldGrid.innerHTML = '<p>No fields found. Add your first field.</p>';
            return;
        }

        fields.forEach(field => {
            const fieldCard = document.createElement('div');
            fieldCard.className = 'field-card';
            fieldCard.innerHTML = `
                <div class="field-header">
                    <h3>${field.field_name}</h3>
                    <div class="field-actions">
                        <button class="btn btn-secondary" onclick="editField(${field.field_id})">Edit</button>
                        <button class="btn btn-danger" onclick="deleteField(${field.field_id})">Delete</button>
                    </div>
                </div>
                <p><strong>Dimensions:</strong> ${field.length}m × ${field.width}m</p>
                <p><strong>Location:</strong> ${field.location}</p>
            `;
            fieldGrid.appendChild(fieldCard);
        });
    } catch (error) {
        debug('Error displaying fields', error);
        console.error('Error displaying fields:', error);
        showMessage('Error displaying fields: ' + error.message, 'error');
    }
}

function updateFieldInfo(fieldName) {
    debug('Updating field info', fieldName);
    
    // Fetch the field data from the database
    fetchFields().then(fields => {
        const field = fields.find(f => f.field_name === fieldName);
        
        if (field) {
            document.getElementById('fieldName').value = field.field_name;
            document.getElementById('fieldLength').value = field.length;
            document.getElementById('fieldWidth').value = field.width;
            document.getElementById('fieldLocation').value = field.location;
            generateRandomValues();
        } else {
            document.getElementById('fieldName').value = '';
            document.getElementById('fieldLength').value = '';
            document.getElementById('fieldWidth').value = '';
            document.getElementById('fieldLocation').value = '';
        }
    });
}

function showRecommendation(crop, conditions) {
    debug('Showing recommendation', { crop, conditions });
    
    const recommendationCard = document.createElement('div');
    recommendationCard.className = 'recommendation-card';
    
    recommendationCard.innerHTML = `
        <div class="recommendation-header">
            <div class="recommendation-icon">🌱</div>
            <h2 class="recommendation-title">Crop Recommendation</h2>
        </div>
        
        <div class="crop-name">
            <h3>${crop}</h3>
        </div>
        
        <div class="conditions-grid">
            <div class="condition-card">
                <div class="condition-value">${conditions.temperature}°C</div>
                <div class="condition-label">Temperature</div>
            </div>
            <div class="condition-card">
                <div class="condition-value">${conditions.humidity}%</div>
                <div class="condition-label">Humidity</div>
            </div>
            <div class="condition-card">
                <div class="condition-value">${conditions.ph}</div>
                <div class="condition-label">pH Level</div>
            </div>
        </div>
        
        <div class="success-rate">
            <div>Success Rate</div>
            <div class="progress-bar">
                <div class="progress-fill">85%</div>
            </div>
        </div>
    `;

    const recommendationSection = document.getElementById('recommendationSection');
    recommendationSection.innerHTML = '';
    recommendationSection.appendChild(recommendationCard);
    recommendationSection.style.display = 'block';

    // Show the compatibility checker after recommendation is made
    document.getElementById('compatibilitySection').style.display = 'block';

    setTimeout(() => {
        const progressFill = recommendationCard.querySelector('.progress-fill');
        progressFill.style.width = '85%';
    }, 100);
}

async function deleteField(fieldId) {
    debug('Deleting field', fieldId);
    
    if (!confirm('Are you sure you want to delete this field?')) return;
    
    try {
        const response = await authenticatedFetch(`http://localhost:5000/fields/${fieldId}`, {
            method: 'DELETE'
        });

        debug('Delete field response status', response.status);
        
        if (response.ok) {
            const result = await response.json();
            debug('Delete field response data', result);
            
            showMessage('Field deleted successfully');
            displayFields(); // Refresh the field list
            loadFieldsToDropdown(); // Reload fields in dropdown
            
            // Refresh the overview section
            loadAllCrops();
        } else {
            throw new Error('Failed to delete field');
        }
    } catch (error) {
        debug('Error deleting field', error);
        console.error('Error deleting field:', error);
        showMessage(error.message, 'error');
    }
}

function editField(fieldId) {
    debug('Edit field', fieldId);
    alert('Edit functionality will be implemented here for field ID: ' + fieldId);
}

function showMessage(message, type = 'success') {
    debug('Showing message', { message, type });
    
    const messageDiv = document.getElementById('formMessages');
    messageDiv.textContent = message;
    messageDiv.className = type;
    messageDiv.style.display = 'block';
    
    if (type === 'success') {
        messageDiv.style.backgroundColor = '#d4edda';
        messageDiv.style.color = '#155724';
        messageDiv.style.border = '1px solid #c3e6cb';
    } else {
        messageDiv.style.backgroundColor = '#f8d7da';
        messageDiv.style.color = '#721c24';
        messageDiv.style.border = '1px solid #f5c6cb';
    }
    
    // Hide message after 5 seconds
    setTimeout(() => {
        messageDiv.style.display = 'none';
    }, 5000);
}

function showTrackCropMessage(message, type = 'success') {
    debug('Showing track crop message', { message, type });
    
    const messageDiv = document.getElementById('trackCropMessages');
    messageDiv.textContent = message;
    messageDiv.className = type;
    messageDiv.style.display = 'block';
    
    if (type === 'success') {
        messageDiv.style.backgroundColor = '#d4edda';
        messageDiv.style.color = '#155724';
        messageDiv.style.border = '1px solid #c3e6cb';
    } else {
        messageDiv.style.backgroundColor = '#f8d7da';
        messageDiv.style.color = '#721c24';
        messageDiv.style.border = '1px solid #f5c6cb';
    }
    
    // Hide message after 5 seconds
    setTimeout(() => {
        messageDiv.style.display = 'none';
    }, 5000);
}

function showEditCropMessage(message, type = 'success') {
    debug('Showing edit crop message', { message, type });
    
    const messageDiv = document.getElementById('editCropMessages');
    messageDiv.textContent = message;
    messageDiv.className = type;
    messageDiv.style.display = 'block';
    
    if (type === 'success') {
        messageDiv.style.backgroundColor = '#d4edda';
        messageDiv.style.color = '#155724';
        messageDiv.style.border = '1px solid #c3e6cb';
    } else {
        messageDiv.style.backgroundColor = '#f8d7da';
        messageDiv.style.color = '#721c24';
        messageDiv.style.border = '1px solid #f5c6cb';
    }
    
    // Hide message after 5 seconds
    setTimeout(() => {
        messageDiv.style.display = 'none';
    }, 5000);
}

// Improved function to load crop assignment
async function loadCropAssignment(fieldName) {
    debug('Loading crop assignment', fieldName);
    
    // Hide the edit button by default
    document.getElementById('editCropButton').style.display = 'none';
    
    if (!fieldName) {
        return;
    }
    
    try {
        // Try to fetch crop tracking data from the database
        const response = await authenticatedFetch(`http://localhost:5000/track-crop/${fieldName}`);
        debug('Fetch crop tracking data response status', response.status);
        
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        
        const trackCropData = await response.json();
        debug('Fetched crop tracking data', trackCropData);
        
        if (trackCropData.length > 0) {
            // Use the most recent crop tracking data
            const latestCrop = trackCropData[0];
            
            // Store the track crop ID in a data attribute for easy access
            document.getElementById('trackCropStatus').dataset.trackCropId = latestCrop.id;
            debug('Stored track crop ID in data attribute', latestCrop.id);
            
            // Update the UI with the crop tracking data
            updateTrackCropSection(fieldName, latestCrop);
            
            // Show the edit button since we have crop data from the database
            const editButton = document.getElementById('editCropButton');
            editButton.style.display = 'block';
            editButton.style.visibility = 'visible';
            
            debug('Edit button should be visible now');
            return;
        }
        
        // Fallback to localStorage if no data in database
        const crop = localStorage.getItem(`crop_${fieldName}`);
        const startDate = localStorage.getItem(`startDate_${fieldName}`);

        if (crop && startDate) {
            updateTrackCropSection(fieldName);
            // Don't show edit button for localStorage data
            document.getElementById('editCropButton').style.display = 'none';
        } else {
            // If no crop is assigned, show the crop assignment form
            document.getElementById('cropAssignmentForm').style.display = 'block';
            document.getElementById('editCropForm').style.display = 'none';
            
            // Clear the form
            document.getElementById('cropSelect').value = '';
            document.getElementById('startDateInput').value = '';
            document.getElementById('cropNotes').value = '';
        }
    } catch (error) {
        debug('Error loading crop assignment', error);
        console.error('Error loading crop assignment:', error);
        
        // Fallback to localStorage
        const crop = localStorage.getItem(`crop_${fieldName}`);
        const startDate = localStorage.getItem(`startDate_${fieldName}`);

        if (crop && startDate) {
            updateTrackCropSection(fieldName);
            // Don't show edit button for localStorage data
            document.getElementById('editCropButton').style.display = 'none';
        } else {
            // If no crop is assigned, show the crop assignment form
            document.getElementById('cropAssignmentForm').style.display = 'block';
            document.getElementById('editCropForm').style.display = 'none';
        }
    }
}

// Improved function to show edit crop form
async function showEditCropForm(fieldName) {
    debug('Showing edit crop form', fieldName);
    
    if (!fieldName) {
        alert('Please select a field first');
        return;
    }
    
    try {
        // Get the track crop ID from the data attribute
        const trackCropId = document.getElementById('trackCropStatus').dataset.trackCropId;
        
        debug('Track crop ID from data attribute', trackCropId);
        
        if (!trackCropId) {
            debug('No track crop ID found in data attribute');
            
            // Fallback: Try to fetch the latest crop data for this field
            const response = await authenticatedFetch(`http://localhost:5000/track-crop/${fieldName}`);
            const trackCropData = await response.json();
            
            if (trackCropData.length > 0) {
                const latestCrop = trackCropData[0];
                document.getElementById('trackCropStatus').dataset.trackCropId = latestCrop.id;
                
                // Populate the edit form with this data
                document.getElementById('editTrackCropId').value = latestCrop.id;
                document.getElementById('editCropSelect').value = latestCrop.crop_planted;
                document.getElementById('editStartDateInput').value = latestCrop.date_planted;
                document.getElementById('editCropNotes').value = latestCrop.notes || '';
                
                // Show the edit form
                document.getElementById('editCropForm').style.display = 'block';
                
                // Hide the crop assignment form and edit button
                document.getElementById('cropAssignmentForm').style.display = 'none';
                document.getElementById('editCropButton').style.display = 'none';
                
                return;
            } else {
                throw new Error('No crop tracking data found for this field');
            }
        }
        
        // Fetch the specific crop tracking record by ID
        debug('Fetching crop tracking record by ID', trackCropId);
        const response = await authenticatedFetch(`http://localhost:5000/track-crop-by-id/${trackCropId}`);
        debug('Fetch specific crop tracking record response status', response.status);
        
        if (!response.ok) {
            const errorData = await response.json();
            debug('Error response data', errorData);
            throw new Error(errorData.message || 'Failed to fetch crop tracking record');
        }
        
        const cropData = await response.json();
        debug('Fetched specific crop tracking record', cropData);
        
        // Populate the edit form
        document.getElementById('editTrackCropId').value = cropData.id;
        document.getElementById('editCropSelect').value = cropData.crop_planted;
        document.getElementById('editStartDateInput').value = cropData.date_planted;
        document.getElementById('editCropNotes').value = cropData.notes || '';
        
        // Show the edit form
        document.getElementById('editCropForm').style.display = 'block';
        
        // Hide the crop assignment form and edit button
        document.getElementById('cropAssignmentForm').style.display = 'none';
        document.getElementById('editCropButton').style.display = 'none';
        
    } catch (error) {
        debug('Error showing edit crop form', error);
        console.error('Error showing edit crop form:', error);
        
        // More user-friendly error message
        const errorMessage = `Could not load crop data for editing. ${error.message}. Please try refreshing the page or adding crop data first.`;
        showEditCropMessage(errorMessage, 'error');
        
        // Show the crop assignment form as a fallback
        document.getElementById('cropAssignmentForm').style.display = 'block';
        document.getElementById('editCropForm').style.display = 'none';
        document.getElementById('editCropButton').style.display = 'none';
    }
}

// Improved function to update track crop section
function updateTrackCropSection(fieldName, cropData = null) {
    debug('Updating track crop section', { fieldName, cropData });
    
    // Hide the edit button by default
    document.getElementById('editCropButton').style.display = 'none';
    
    if (!fieldName) {
        document.getElementById('trackCropTitle').textContent = 'Select a field to track crops';
        document.getElementById('trackCropStatus').textContent = '';
        document.getElementById('cropAssignmentForm').style.display = 'none';
        document.getElementById('editCropForm').style.display = 'none';
        return;
    }

    let crop, startDate, notes, trackCropId;
    
    if (cropData) {
        // Use data from the database
        crop = cropData.crop_planted;
        startDate = cropData.date_planted;
        notes = cropData.notes;
        trackCropId = cropData.id;
        
        // Store the track crop ID in a data attribute for easy access
        document.getElementById('trackCropStatus').dataset.trackCropId = trackCropId;
        
        // Show the edit button since we have crop data from the database
        document.getElementById('editCropButton').style.display = 'block';
    } else {
        // Fallback to localStorage
        crop = localStorage.getItem(`crop_${fieldName}`);
        startDate = localStorage.getItem(`startDate_${fieldName}`);
        notes = '';
    }

    if (!crop || !startDate) {
        document.getElementById('trackCropTitle').textContent = `Assign crop to ${fieldName}`;
        document.getElementById('trackCropStatus').textContent = '';
        document.getElementById('cropAssignmentForm').style.display = 'block';
        document.getElementById('editCropForm').style.display = 'none';
        return;
    }

    // Calculate the current day based on the start date
    const currentDay = calculateCurrentDay(startDate);
    
    // Determine current stage based on days elapsed
    let currentStage = "Planting";
    let duration = 120; // Default duration
    
    if (crop === "Maize") {
        duration = 140;
        if (currentDay > 63) currentStage = "Reproductive";
        else if (currentDay > 21) currentStage = "Vegetative";
    } else if (crop === "Wheat") {
        duration = 120;
        if (currentDay > 60) currentStage = "Reproductive";
        else if (currentDay > 21) currentStage = "Vegetative";
    } else if (crop === "Potatoes") {
        duration = 110;
        if (currentDay > 75) currentStage = "Maturity";
        else if (currentDay > 40) currentStage = "Reproductive";
        else if (currentDay > 20) currentStage = "Vegetative";
    } else if (crop === "Rice") {
        duration = 130;
        if (currentDay > 70) currentStage = "Reproductive";
        else if (currentDay > 25) currentStage = "Vegetative";
    } else if (crop === "Beans") {
        duration = 90;
        if (currentDay > 60) currentStage = "Maturity";
        else if (currentDay > 35) currentStage = "Reproductive";
        else if (currentDay > 15) currentStage = "Vegetative";
    } else if (crop === "Tomatoes") {
        duration = 100;
        if (currentDay > 70) currentStage = "Maturity";
        else if (currentDay > 40) currentStage = "Reproductive";
        else if (currentDay > 20) currentStage = "Vegetative";
    }

    // Calculate the expected harvest date
    const expectedHarvestDate = calculateHarvestDate(startDate, duration);

    // Update header
    document.getElementById('trackCropTitle').textContent = `Track Crop: ${crop}`;
    let statusText = `Current Stage: ${currentStage} (Day ${currentDay}) | Expected Harvest: ${expectedHarvestDate}`;
    if (notes) {
        statusText += `<br><br><strong>Notes:</strong> ${notes}`;
    }
    document.getElementById('trackCropStatus').innerHTML = statusText;
    document.getElementById('cropAssignmentForm').style.display = 'none';
    document.getElementById('editCropForm').style.display = 'none';

    // Update growth stages
    const stages = ['Planting', 'Vegetative', 'Reproductive', 'Maturity'];
    const currentStageIndex = stages.indexOf(currentStage);

    stages.forEach((stage, index) => {
        const stageElement = document.getElementById(`${stage.toLowerCase()}Stage`);
        if (stageElement) {
            const statusText = index < currentStageIndex ? 'Completed' :
                            index === currentStageIndex ? `In Progress - Day ${currentDay}` :
                            'Upcoming';
            stageElement.querySelector('p').textContent = statusText;
        }
    });

    // Update timeline
    updateCropTimeline(crop, currentDay, startDate);
    
    // Show the edit button if we have crop data from the database
    if (cropData) {
        document.getElementById('editCropButton').style.display = 'block';
    }
}

function updateCropTimeline(crop, currentDay, startDate) {
    debug('Updating crop timeline', { crop, currentDay, startDate });
    
    const timelineContainer = document.getElementById('cropTimeline');
    timelineContainer.innerHTML = '';

    let timeline = [];

    // Define timelines for different crops
    if (crop === "Maize") {
        timeline = [
            { day: "1", stage: "Planting", description: "Seeds planted in moist soil" },
            { day: "5-13", stage: "Emergence", description: "Seedlings emerge from soil" },
            { day: "14-25", stage: "Early Vegetative", description: "First true leaves appear" },
            { day: "26-41", stage: "V6 Stage", description: "Six leaves fully emerged" },
            { day: "42-55", stage: "V12 Stage", description: "Rapid growth begins" },
            { day: "56-69", stage: "Tasseling", description: "Tassels emerge" },
            { day: "70-89", stage: "Silking", description: "Silks emerge from ears" },
            { day: "90-111", stage: "Kernel Development", description: "Kernels fill with starch" },
            { day: "112-125", stage: "Dent Stage", description: "Kernels begin to dry" },
            { day: "126-140", stage: "Maturity", description: "Black layer forms" }
        ];
    } else if (crop === "Wheat") {
        timeline = [
            { day: "1", stage: "Planting", description: "Seeds sown at appropriate depth" },
            { day: "7-13", stage: "Germination", description: "First shoots emerge" },
            { day: "14-29", stage: "Tillering", description: "Multiple stems develop" },
            { day: "30-49", stage: "Stem Extension", description: "Rapid vertical growth" },
            { day: "50-64", stage: "Heading", description: "Seed heads emerge" },
            { day: "65-79", stage: "Flowering", description: "Pollination occurs" },
            { day: "80-95", stage: "Grain Fill", description: "Kernels develop" },
            { day: "95-120", stage: "Maturity", description: "Grain hardens and dries" }
        ];
    } else if (crop === "Potatoes") {
        timeline = [
            { day: "1", stage: "Planting", description: "Seed potatoes planted" },
            { day: "14-20", stage: "Emergence", description: "Sprouts break through" },
            { day: "21-40", stage: "Vegetative Growth", description: "Leaf development" },
            { day: "41-55", stage: "Tuber Initiation", description: "Small potatoes form" },
            { day: "56-75", stage: "Tuber Bulking", description: "Potatoes increase in size" },
            { day: "76-95", stage: "Maturation", description: "Vines die back" },
            { day: "96-110", stage: "Harvest Ready", description: "Ready for harvest" }
        ];
    } else if (crop === "Rice") {
        timeline = [
            { day: "1", stage: "Planting", description: "Seeds sown in wet soil" },
            { day: "5-14", stage: "Germination", description: "Seeds begin to sprout" },
            { day: "15-25", stage: "Seedling", description: "Young plants develop" },
            { day: "26-50", stage: "Tillering", description: "Multiple stems form" },
            { day: "51-70", stage: "Stem Elongation", description: "Plants grow taller" },
            { day: "71-90", stage: "Panicle Development", description: "Grain heads form" },
            { day: "91-110", stage: "Flowering", description: "Pollination occurs" },
            { day: "111-130", stage: "Maturity", description: "Grains ripen and dry" }
        ];
    } else if (crop === "Beans") {
        timeline = [
            { day: "1", stage: "Planting", description: "Seeds planted in warm soil" },
            { day: "5-8", stage: "Emergence", description: "Seedlings break through soil" },
            { day: "9-15", stage: "Primary Leaves", description: "First true leaves unfold" },
            { day: "16-35", stage: "Vegetative Growth", description: "Plant develops more leaves" },
            { day: "36-45", stage: "Flowering", description: "Flowers appear" },
            { day: "46-60", stage: "Pod Development", description: "Pods form and fill" },
            { day: "61-90", stage: "Maturity", description: "Pods dry and ready for harvest" }
        ];
    } else if (crop === "Tomatoes") {
        timeline = [
            { day: "1", stage: "Planting", description: "Seedlings transplanted" },
            { day: "1-14", stage: "Establishment", description: "Plants establish roots" },
            { day: "15-30", stage: "Vegetative Growth", description: "Plants grow larger" },
            { day: "31-40", stage: "Flowering", description: "Flowers appear" },
            { day: "41-60", stage: "Fruit Set", description: "Small fruits begin to form" },
            { day: "61-80", stage: "Fruit Development", description: "Fruits grow larger" },
            { day: "81-100", stage: "Ripening", description: "Fruits change color and ripen" }
        ];
    }

    // Create timeline items
    timeline.forEach((item, index) => {
        const dayStart = parseInt(item.day.split('-')[0]);
        const isCompleted = currentDay >= dayStart;
        const isCurrent = currentDay >= dayStart && 
            (item.day.includes('-') ? 
                currentDay <= parseInt(item.day.split('-')[1]) : 
                currentDay === dayStart);

        const timelineItem = document.createElement('div');
        timelineItem.className = `timeline-item ${index % 2 === 0 ? 'left' : 'right'} 
            ${isCompleted ? 'completed' : ''} 
            ${isCurrent ? 'current' : ''}`;

        timelineItem.innerHTML = `
            <div class="timeline-content">
                <h3>Day ${item.day}: ${item.stage}</h3>
                <p>${item.description}</p>
            </div>
        `;

        timelineContainer.appendChild(timelineItem);
    });
}

function calculateCurrentDay(plantingDate) {
    debug('Calculating current day', plantingDate);
    
    const start = new Date(plantingDate);
    const now = new Date();
    const timeDifference = now - start;
    const daysDifference = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
    return daysDifference + 1; // +1 because day 1 is the planting day
}

function calculateHarvestDate(startDate, duration) {
    debug('Calculating harvest date', { startDate, duration });
    
    const start = new Date(startDate);
    const harvestDate = new Date(start);
    harvestDate.setDate(start.getDate() + duration);
    return harvestDate.toISOString().split('T')[0];
}

// Check server health on startup
async function checkServerHealth() {
    debug('Checking server health');
    
    try {
        const response = await authenticatedFetch('http://localhost:5000/health');
        debug('Server health check response status', response.status);
        
        if (!response.ok) {
            showMessage('Warning: Server connection issues. Some features may not work properly.', 'error');
        
        }
    } catch (error) {
        debug('Server health check failed', error);
        console.error('Server health check failed:', error);
        showMessage('Warning: Cannot connect to server. Please ensure the backend is running.', 'error');
    }
}

// Call health check on startup
checkServerHealth();

// Make functions available globally
window.setActiveTab = setActiveTab;
window.deleteField = deleteField;
window.editField = editField;

// Check if user is authenticated
function isAuthenticated() {
    const token = localStorage.getItem("auth_token");
    return !!token; // Convert to boolean
}

// Get authentication token
function getAuthToken() {
    return localStorage.getItem("auth_token");
}

// Show authentication error
function showAuthError(message = "You need to be logged in to use this feature.") {
    const authErrorMessage = document.getElementById('authErrorMessage');
    authErrorMessage.textContent = message;
    authErrorMessage.style.display = 'block';
    
    // Hide after 5 seconds
    setTimeout(() => {
        authErrorMessage.style.display = 'none';
    }, 5000);
}

// Authenticated fetch function
async function authenticatedFetch(url, options = {}) {
    if (!isAuthenticated()) {
        showAuthError();
        throw new Error("Not authenticated");
    }

    const token = getAuthToken();
    
    // Create a new headers object instead of modifying the existing one
    const newHeaders = new Headers(options.headers || {});
    newHeaders.set('Authorization', `Bearer ${token}`);
    
    if (!newHeaders.has('Content-Type') && !(options.body instanceof FormData)) {
        newHeaders.set('Content-Type', 'application/json');
    }
    
    try {
        // Use the native fetch directly, not a recursive call
        const response = await fetch(url, {
            ...options,
            headers: newHeaders
        });

        if (response.status === 401) {
            showAuthError("Your session has expired. Please log in again.");
            throw new Error("Unauthorized: Session expired");
        }

        return response;
    } catch (error) {
        console.error("API request failed:", error);
        throw error;
    }
}

const originalAddEventListener = EventTarget.prototype.addEventListener;
EventTarget.prototype.addEventListener = function(type, listener, options) {
    console.log(`Adding event listener: ${type} to`, this);
    return originalAddEventListener.call(this, type, listener, options);
};
// Crop compatibility check function
async function checkCropCompatibility() {
    const cropInput = document.getElementById("cropInput").value.trim().toLowerCase();
    const resultSection = document.getElementById("compatibilityResult");
    const feedbackContent = document.getElementById("feedbackContent");
    const scoreValue = document.getElementById("scoreValue");
    const scoreContainer = document.querySelector(".compatibility-score");

    if (!cropInput) {
        alert("Please enter a crop name.");
        return;
    }

    const data = {
        desired_crop: cropInput,
        N: parseInt(document.getElementById("N").value) || 0,
        P: parseInt(document.getElementById("P").value) || 0,
        K: parseInt(document.getElementById("K").value) || 0,
        temperature: parseFloat(document.getElementById("temperature").value) || 0,
        humidity: parseFloat(document.getElementById("humidity").value) || 0,
        ph: parseFloat(document.getElementById("ph").value) || 0,
        rainfall: parseFloat(document.getElementById("rainfall").value) || 0,
    };

    try {
        feedbackContent.innerHTML = "<p>Analyzing compatibility...</p>";
        resultSection.style.display = "block";

        // For demonstration purposes, we'll simulate a response
        setTimeout(() => {
            // Simulate different responses based on crop input
            let compatibilityScore, feedback, recommendedCrop;
            
            if (["maize", "corn"].includes(cropInput)) {
                compatibilityScore = 85;
                recommendedCrop = "Maize";
                feedback = "Maize is highly compatible with your current soil conditions.\n\n" +
                    "Nitrogen levels are optimal for maize growth.\n" +
                    "Phosphorus and potassium levels are sufficient.\n" +
                    "Temperature and rainfall are within ideal range for maize cultivation.";
            } else if (["wheat", "rice", "barley"].includes(cropInput)) {
                compatibilityScore = 70;
                recommendedCrop = cropInput.charAt(0).toUpperCase() + cropInput.slice(1);
                feedback = `${recommendedCrop} is moderately compatible with your current soil conditions.\n\n` +
                    "Nitrogen levels are slightly below optimal.\n" +
                    "Consider adding nitrogen-rich fertilizers before planting.\n" +
                    "Temperature and humidity conditions are favorable.";
            } else if (["tomato", "tomatoes", "potato", "potatoes"].includes(cropInput)) {
                compatibilityScore = 60;
                recommendedCrop = cropInput.includes("tomato") ? "Tomatoes" : "Potatoes";
                feedback = `${recommendedCrop} can grow in these conditions with proper care.\n\n` +
                    "Soil pH is slightly outside the optimal range.\n" +
                    "Consider soil amendments to adjust pH levels.\n" +
                    "Ensure consistent watering as these crops are sensitive to drought.";
            } else {
                compatibilityScore = 45;
                recommendedCrop = cropInput.charAt(0).toUpperCase() + cropInput.slice(1);
                feedback = `${recommendedCrop} has low compatibility with current conditions.\n\n` +
                    "Several soil parameters are outside the optimal range.\n" +
                    "Significant soil amendments would be required.\n" +
                    "Consider alternative crops better suited to your conditions.";
            }

            const formattedFeedback = feedback.replace(/\n/g, "<br>");
            feedbackContent.innerHTML = `
                <h4>${recommendedCrop.toUpperCase()} Analysis</h4>
                <div class="expert-feedback">${formattedFeedback}</div>
            `;
            
            scoreValue.textContent = `${compatibilityScore}%`;
            scoreContainer.className = "compatibility-score"; // Reset classes
            
            if (compatibilityScore >= 75) {
                scoreContainer.classList.add("compatibility-high");
            } else if (compatibilityScore >= 50) {
                scoreContainer.classList.add("compatibility-medium");
            } else {
                scoreContainer.classList.add("compatibility-low");
            }
            
            const scoreFill = scoreContainer.querySelector(".score-fill");
            scoreFill.style.width = `${compatibilityScore}%`;
        }, 1000);
    } catch (error) {
        console.error("Error:", error);
        feedbackContent.innerHTML = `<p>Error: ${error.message}</p>`;
    }
}
